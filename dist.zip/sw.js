const CACHE_NAME = 'nana-pos-shell-v2';
const WASM_CACHE_NAME = 'nana-pos-wasm-v1';

const STATIC_PRECACHE_URLS = [
  '/',
  '/index.html',
  '/manifest.json',
  '/icon.svg',
  '/pwa-192x192.png',
  '/pwa-512x512.png',
  '/apple-touch-icon.png'
];

// URLs des fichiers WebAssembly FFmpeg à pré-cacher pour le 100% hors-ligne
const FFMPEG_PRECACHE_URLS = [
  'https://unpkg.com/@ffmpeg/core@0.12.6/dist/esm/ffmpeg-core.js',
  'https://unpkg.com/@ffmpeg/core@0.12.6/dist/esm/ffmpeg-core.wasm',
];

// 1. Installation du Service Worker et mise en cache du App Shell + WASM
self.addEventListener('install', (event) => {
  event.waitUntil(
    Promise.all([
      caches.open(CACHE_NAME).then((cache) => {
        console.log('[ServiceWorker] Mise en cache initiale de l’App Shell');
        return cache.addAll(STATIC_PRECACHE_URLS).catch((err) => {
          console.warn('[ServiceWorker] Erreur pré-cache Shell :', err);
        });
      }),
      caches.open(WASM_CACHE_NAME).then((cache) => {
        console.log('[ServiceWorker] Mise en cache initiale FFmpeg.wasm');
        return cache.addAll(FFMPEG_PRECACHE_URLS).catch((err) => {
          console.warn('[ServiceWorker] Pré-cache FFmpeg en arrière-plan (chargé à la demande si échec) :', err);
        });
      }),
    ]).then(() => self.skipWaiting())
  );
});

// 2. Activation du Service Worker et purge des anciens caches (en préservant WASM_CACHE_NAME)
self.addEventListener('activate', (event) => {
  const allowedCaches = [CACHE_NAME, WASM_CACHE_NAME];
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames
          .filter((name) => !allowedCaches.includes(name))
          .map((name) => {
            console.log('[ServiceWorker] Suppression ancien cache :', name);
            return caches.delete(name);
          })
      );
    }).then(() => self.clients.claim())
  );
});

// 3. Stratégies de requêtes :
// - Cache-First pour les binaires WASM (FFmpeg, Whisper ONNX)
// - Network-First pour la navigation
// - Stale-While-Revalidate pour les assets statiques
self.addEventListener('fetch', (event) => {
  const req = event.request;
  const url = new URL(req.url);

  // Ne pas intercepter les requêtes non-GET ou externes aux APIs Firebase / Gemini
  if (req.method !== 'GET') return;
  if (
    url.hostname.includes('firestore.googleapis.com') ||
    url.hostname.includes('firebaseio.com') ||
    url.hostname.includes('generativelanguage.googleapis.com') ||
    url.hostname.includes('identitytoolkit.googleapis.com') ||
    url.pathname.startsWith('/api/')
  ) {
    return;
  }

  // A. Mise en cache pérenne Cache-First pour WebAssembly et Modèles IA (FFmpeg.wasm & Whisper ONNX)
  const isWasmOrModel =
    url.pathname.endsWith('.wasm') ||
    url.pathname.endsWith('.onnx') ||
    url.pathname.endsWith('.bin') ||
    url.hostname.includes('huggingface.co') ||
    url.hostname.includes('cdn-lfs.huggingface.co') ||
    (url.hostname.includes('unpkg.com') && url.pathname.includes('@ffmpeg/core')) ||
    (url.hostname.includes('jsdelivr.net') && url.pathname.includes('ffmpeg'));

  if (isWasmOrModel) {
    event.respondWith(
      caches.open(WASM_CACHE_NAME).then(async (cache) => {
        const cachedResponse = await cache.match(req);
        if (cachedResponse) {
          return cachedResponse;
        }

        try {
          const networkResponse = await fetch(req);
          if (networkResponse && (networkResponse.status === 200 || networkResponse.type === 'opaque')) {
            cache.put(req, networkResponse.clone());
          }
          return networkResponse;
        } catch (fetchErr) {
          console.warn('[ServiceWorker] Impossible de récupérer le fichier WASM/Modèle en direct :', url.href, fetchErr);
          throw fetchErr;
        }
      })
    );
    return;
  }

  // B. Navigation HTML : Network-First avec fallback vers cache /
  if (req.mode === 'navigate') {
    event.respondWith(
      fetch(req)
        .then((networkRes) => {
          if (networkRes && networkRes.status === 200) {
            const resClone = networkRes.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put(req, resClone));
          }
          return networkRes;
        })
        .catch(async () => {
          console.log('[ServiceWorker] Mode Hors-ligne : chargement du fallback Shell');
          const cache = await caches.open(CACHE_NAME);
          const cachedNavigate = await cache.match(req);
          if (cachedNavigate) return cachedNavigate;
          return (await cache.match('/index.html')) || (await cache.match('/'));
        })
    );
    return;
  }

  // C. Assets statiques de même origine (JS, CSS, images, polices) : Stale-While-Revalidate
  if (url.origin === self.location.origin) {
    event.respondWith(
      caches.match(req).then((cachedRes) => {
        const fetchPromise = fetch(req)
          .then((networkRes) => {
            if (networkRes && networkRes.status === 200) {
              const resClone = networkRes.clone();
              caches.open(CACHE_NAME).then((cache) => cache.put(req, resClone));
            }
            return networkRes;
          })
          .catch(() => cachedRes);

        return cachedRes || fetchPromise;
      })
    );
    return;
  }
});

// Écoute de messages clients
self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }
});
