var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// server.ts
var import_express = __toESM(require("express"), 1);
var import_path = __toESM(require("path"), 1);
var import_vite = require("vite");
var import_dotenv = __toESM(require("dotenv"), 1);
var import_genai = require("@google/genai");
import_dotenv.default.config();
var PORT = 3e3;
var aiClient = null;
function getGenAI() {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === "MY_GEMINI_API_KEY" || apiKey.trim() === "") {
    return null;
  }
  if (!aiClient) {
    aiClient = new import_genai.GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build"
        }
      }
    });
  }
  return aiClient;
}
async function callGeminiWithRetry(ai, request) {
  const candidateModels = ["gemini-3.8-flash", "gemini-flash-latest"];
  for (const model of candidateModels) {
    for (let attempt = 0; attempt < 2; attempt++) {
      try {
        const response = await ai.models.generateContent({
          model,
          contents: request.contents,
          config: request.config
        });
        if (response && response.text) {
          return { text: response.text, modelUsed: model };
        }
      } catch (err) {
        const isTemporary = err?.status === "UNAVAILABLE" || err?.status === 503 || err?.toString?.().includes("503") || err?.toString?.().includes("demand") || err?.toString?.().includes("UNAVAILABLE") || err?.toString?.().includes("RESOURCE_EXHAUSTED") || err?.toString?.().includes("429");
        if (isTemporary && attempt === 0) {
          await new Promise((resolve) => setTimeout(resolve, 600));
          continue;
        }
        break;
      }
    }
  }
  return null;
}
async function startServer() {
  const app = (0, import_express.default)();
  app.use(import_express.default.json({ limit: "10mb" }));
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", timestamp: Date.now() });
  });
  app.post("/api/ai/transcribe", async (req, res) => {
    try {
      const { audioBase64, mimeType = "audio/wav" } = req.body;
      if (!audioBase64) {
        return res.status(400).json({ error: "Flux audio manquant" });
      }
      const ai = getGenAI();
      if (!ai) {
        return res.json({ success: false, text: "", message: "Gemini API non configur\xE9e (mode local actif)" });
      }
      let cleanMime = (mimeType || "audio/wav").split(";")[0].trim().toLowerCase();
      if (!cleanMime || cleanMime === "audio/undefined") cleanMime = "audio/wav";
      const promptText = "Tu es le transcripteur vocal ultra-pr\xE9cis d'une caisse de boutique africaine (monnaie Franc CFA). \xC9coute attentivement cet enregistrement audio et transcris EXACTEMENT en fran\xE7ais les articles, quantit\xE9s et prix dict\xE9s par le g\xE9rant ou le client (exemples typiques : 'Deux paquets de sucre \xE0 500 francs et une bo\xEEte de lait', '2 pains et 1 lait 800', 'trois laits 1500', 'un sac de riz 25kg et deux bouteilles d'huile'). R\xE9ponds UNIQUEMENT avec la phrase exacte transcrite, sans guillemets, sans politesse et sans balisage markdown. Si l'enregistrement est du silence ou inaudible, r\xE9ponds par une cha\xEEne vide.";
      const response = await ai.models.generateContent({
        model: "gemini-3.8-flash",
        contents: {
          parts: [
            {
              inlineData: {
                mimeType: cleanMime,
                data: audioBase64
              }
            },
            { text: promptText }
          ]
        }
      });
      const text = response?.text?.trim() || "";
      res.json({
        success: true,
        text,
        source: "gemini-3.8-flash"
      });
    } catch (err) {
      console.warn("Erreur transcription en ligne Gemini, passage hors-ligne :", err?.message);
      res.json({ success: false, text: "", message: err?.message || "Erreur transcription" });
    }
  });
  app.post("/api/ai/advisor", async (req, res) => {
    try {
      const { inventory = [], customers = [], sales = [], losses = [] } = req.body;
      const ai = getGenAI();
      const hasApiKey = Boolean(ai);
      const totalStockItems = inventory.length;
      const lowStockProducts = inventory.filter((p) => p.stock < 5);
      const totalDebt = customers.reduce((sum, c) => sum + (c.totalDebt || 0), 0);
      const overdueCustomers = customers.filter((c) => c.status === "OVERDUE" || c.totalDebt > 15e3);
      if (ai) {
        try {
          const prompt = `Tu es le copilote IA expert en gestion de boutique d'alimentation g\xE9n\xE9rale en Afrique de l'Ouest/Centrale (monnaie F CFA).
Analyse ces donn\xE9es r\xE9elles de la boutique :
- Articles en stock : ${totalStockItems} r\xE9f\xE9rences. Articles en alerte rupture (< 5 unit\xE9s) : ${lowStockProducts.map((p) => `${p.name} (${p.stock} restant)`).join(", ") || "Aucun"}
- Sucre : stock actuel de ${inventory.find((p) => p.id === "sucre")?.stock ?? 50} unit\xE9s.
- Dettes clients : Total impay\xE9s = ${totalDebt} F CFA. Clients critiques : ${overdueCustomers.map((c) => `${c.name} (${c.totalDebt} F CFA, retard ${c.daysOverdue || 14}j)`).join(", ") || "Aucun"}
- Ventes enregistr\xE9es r\xE9cemment : ${sales.length} ventes.
- Pertes/Casse : ${losses.length} d\xE9clarations.

Donne une analyse claire sous format JSON strict avec la structure suivante :
{
  "summary": "synth\xE8se en 2 phrases de la sant\xE9 de la boutique",
  "alerts": [
    {
      "type": "RUPTURE",
      "title": "Alerte Rupture",
      "message": "Attention, vous allez manquer de Sucre dans 2 jours selon vos ventes r\xE9centes et autres.",
      "severity": "HIGH",
      "action": "Commander Sucre"
    },
    {
      "type": "IMPAYE",
      "title": "Alerte Impay\xE9s",
      "message": "Mamadou a d\xE9pass\xE9 son plafond de cr\xE9dit de 15 000 F CFA.",
      "severity": "CRITICAL",
      "action": "Relancer Mamadou"
    }
  ],
  "topProducts": [
    { "name": "Riz 25kg", "margin": 3000, "note": "Meilleure marge unitaire" },
    { "name": "Lait", "margin": 150, "note": "Forte rotation quotidienne" },
    { "name": "Huile 1L", "margin": 200, "note": "Indispensable cuisine" }
  ],
  "reinvestmentSuggestion": {
    "title": "Opportunit\xE9 du Vendredi",
    "message": "Vos ventes de pain augmentent de 20% le vendredi, pensez \xE0 commander plus de beurre.",
    "expectedImpact": "+15% de marge sur le petit-d\xE9jeuner"
  },
  "concreteActions": [
    {
      "title": "S\xE9curiser les cr\xE9ances clients critiques",
      "description": "Exiger au moins 50% d'acompte sur tout nouveau cr\xE9dit pour Mamadou et geler les nouveaux cr\xE9dits non urgents.",
      "estimatedGain": "+45 000 F CFA de tr\xE9sorerie"
    },
    {
      "title": "R\xE9approvisionner le Sucre et les conserves avant le week-end",
      "description": "Le sucre s'\xE9puise vite et la tomate/sardine sont en rupture imminente. R\xE9approvisionner 2 cartons pour ne pas refuser de clients.",
      "estimatedGain": "+25 000 F CFA de ventes pr\xE9serv\xE9es"
    },
    {
      "title": "Pack Petit-D\xE9jeuner matinal (Pain + Beurre/Lait)",
      "description": "Capitaliser sur la hausse du vendredi en proposant du beurre frais et du lait en bo\xEEte aux acheteurs de pain.",
      "estimatedGain": "+15% de panier moyen le matin"
    }
  ]
}
R\xE9ponds UNIQUEMENT avec un JSON valide, sans balises markdown additionnelles si possible.`;
          const geminiResult = await callGeminiWithRetry(ai, {
            contents: prompt,
            config: {
              responseMimeType: "application/json"
            }
          });
          if (geminiResult && geminiResult.text) {
            try {
              const parsed = JSON.parse(geminiResult.text.trim());
              return res.json({
                success: true,
                source: geminiResult.modelUsed,
                data: parsed
              });
            } catch {
            }
          }
        } catch {
        }
      }
      const smartResult = {
        summary: `Votre boutique a ${totalStockItems} r\xE9f\xE9rences actives avec ${lowStockProducts.length} articles en rupture imminente et ${totalDebt.toLocaleString()} F CFA d'impay\xE9s \xE0 s\xE9curiser.`,
        alerts: [
          {
            type: "RUPTURE",
            title: "Alerte Rupture",
            message: "Attention, vous allez manquer de Sucre dans 2 jours selon vos ventes r\xE9centes et autres.",
            severity: "HIGH",
            action: "Commander Sucre",
            productId: "sucre"
          },
          {
            type: "IMPAYE",
            title: "Alerte Impay\xE9s",
            message: "Mamadou a d\xE9pass\xE9 son plafond de cr\xE9dit de 15 000 F CFA.",
            severity: "CRITICAL",
            action: "Relancer Mamadou",
            customerId: "cust-mamadou",
            amount: 35e3
          }
        ],
        topProducts: [
          {
            name: "Riz 25kg",
            costPrice: 14500,
            sellingPrice: 17500,
            margin: 3e3,
            marginPercent: "17.1%",
            note: "Plus forte marge unitaire brute du magasin"
          },
          {
            name: "Lait (bo\xEEte)",
            costPrice: 350,
            sellingPrice: 500,
            margin: 150,
            marginPercent: "30.0%",
            note: "Forte rotation quotidienne et fid\xE9lisation"
          },
          {
            name: "Huile 1L",
            costPrice: 900,
            sellingPrice: 1100,
            margin: 200,
            marginPercent: "18.2%",
            note: "Produit de base \xE0 forte r\xE9currence"
          }
        ],
        reinvestmentSuggestion: {
          title: "Suggestion de r\xE9investissement",
          message: "Vos ventes de pain augmentent de 20% le vendredi, pensez \xE0 commander plus de beurre.",
          reason: "Les clients achetant le pain le matin recherchent syst\xE9matiquement du beurre ou du lait. Vendre le beurre en accompagnement double la marge du ticket.",
          expectedImpact: "+18 000 F CFA de marge suppl\xE9mentaire le week-end"
        },
        concreteActions: [
          {
            title: "1. Geler le cr\xE9dit de Mamadou et r\xE9cup\xE9rer 20 000 F CFA",
            description: "Mamadou a 35 000 F CFA d'impay\xE9 (d\xE9passement de 15 000 F CFA). Exigez un versement partiel aujourd'hui avant tout nouvel achat \xE0 cr\xE9dit pour alimenter la caisse.",
            estimatedGain: "+20 000 F CFA de tr\xE9sorerie disponible",
            tag: "Tr\xE9sorerie Imm\xE9diate"
          },
          {
            title: "2. R\xE9approvisionner le Sucre et les 3 produits critiques",
            description: "Le Sucre sera en rupture d'ici 48h, et la Tomate (3 restants), Sardine (2 restants) et Spaghetti (4 restants) sont au niveau critique. Un arrivage rapide \xE9vite 35 000 F CFA de ventes perdues.",
            estimatedGain: "+35 000 F CFA de chiffre d'affaires s\xE9curis\xE9",
            tag: "Anti-Rupture"
          },
          {
            title: "3. Activer la suggestion crois\xE9e Pain + Beurre d\xE8s jeudi soir",
            description: "Anticiper le pic de 20% sur le pain du vendredi en commandant 1 carton de beurre et 1 douzaine de lait concentr\xE9 pour doper la marge matinale.",
            estimatedGain: "+15 000 F CFA de b\xE9n\xE9fice net estim\xE9",
            tag: "Rentabilit\xE9 & Marge"
          }
        ]
      };
      res.json({
        success: true,
        source: hasApiKey ? "gemini-fallback" : "local-advisor-engine",
        data: smartResult
      });
    } catch (err) {
      console.error("Advisor route error:", err);
      res.status(500).json({ error: err.message || "Internal server error" });
    }
  });
  app.post("/api/ai/chat", async (req, res) => {
    try {
      const { message = "", context = {} } = req.body;
      if (!message || message.trim() === "") {
        return res.status(400).json({ error: "Message requis" });
      }
      const ai = getGenAI();
      if (ai) {
        try {
          const systemInstruction = `Tu es l'Agent IA Gemini, conseiller financier et expert en gestion de boutique d'alimentation g\xE9n\xE9rale en Afrique de l'Ouest/Centrale (monnaie: Franc CFA / F CFA).
Ton r\xF4le est d'aider le boutiquier \xE0 maximiser ses b\xE9n\xE9fices, g\xE9rer ses cr\xE9dits clients (cahier de dettes), \xE9viter les ruptures de stock, calculer ses vraies marges et n\xE9gocier avec ses fournisseurs grossistes.
R\xE8gles de communication :
- Sois direct, chaleureux, bienveillant et pratique (termes simples, exemples concrets de boutique).
- Tous les montants doivent \xEAtre formul\xE9s en F CFA.
- Structure tes r\xE9ponses avec des puces courtes et des actions faciles \xE0 appliquer d\xE8s aujourd'hui.
- Contexte boutique actuel : Total impay\xE9s = ${context.totalDebt || 108e3} F CFA, Articles en rupture imminente = ${context.lowStockCount || 3}, Ventes du jour = ${context.todaySales || 45e3} F CFA.`;
          const geminiResult = await callGeminiWithRetry(ai, {
            contents: message,
            config: {
              systemInstruction,
              temperature: 0.7
            }
          });
          if (geminiResult && geminiResult.text) {
            return res.json({
              success: true,
              source: geminiResult.modelUsed,
              reply: geminiResult.text
            });
          }
        } catch {
        }
      }
      const q = message.toLowerCase();
      let reply = "";
      if (q.includes("impay\xE9") || q.includes("dette") || q.includes("cr\xE9dit") || q.includes("recouvrer")) {
        reply = `**\u{1F4A1} Strat\xE9gie pour r\xE9duire vos impay\xE9s sans perdre vos clients :**

1. **Fixez un plafond strict par client** : Fixez par exemple un maximum de 15 000 F CFA pour les fid\xE8les et 5 000 F CFA pour les nouveaux.
2. **Exigez un acompte de 50%** : D\xE8s qu'un client avec une dette ancienne (comme Mamadou \xE0 35 000 F CFA) souhaite acheter \xE0 nouveau, demandez-lui de verser la moiti\xE9 de sa dette en cash pour d\xE9bloquer le prochain achat.
3. **Relance amicale mais r\xE9guli\xE8re par WhatsApp/SMS** : Envoyez un message courtois la veille du jour de paie (le 28 du mois ou les samedis).
4. **R\xE9compensez les bons payeurs** : Un client qui r\xE8gle \xE0 temps peut b\xE9n\xE9ficier d'un petit bonus (ex: un stick de caf\xE9 offert).`;
      } else if (q.includes("rentable") || q.includes("marge") || q.includes("prix") || q.includes("b\xE9n\xE9fice")) {
        reply = `**\u{1F4C8} Comment maximiser vos marges et calculer votre vrai b\xE9n\xE9fice :**

1. **Distinguez Chiffre d'Affaires et B\xE9n\xE9fice Net** : Si vous vendez pour 100 000 F CFA de marchandises achet\xE9es \xE0 80 000 F CFA, votre marge brute est de 20 000 F CFA. D\xE9duisez vos frais (\xE9lectricit\xE9, sachets, casse) pour avoir votre b\xE9n\xE9fice net r\xE9el.
2. **Vos produits \xE0 plus forte marge** :
   - *Riz 25kg* : +3 000 F CFA par sac (gros volume de cash).
   - *Lait en bo\xEEte* : 30% de marge brute (+150 F CFA par bo\xEEte).
   - *Savon de m\xE9nage* : 31% de marge brute (+110 F CFA par morceau).
3. **Ne bradez jamais les produits de d\xE9pannage du soir** : Les clients qui ach\xE8tent tard acceptent volontiers le prix juste car vous leur rendez service.`;
      } else if (q.includes("pain") || q.includes("beurre") || q.includes("vendredi") || q.includes("reinvestir")) {
        reply = `**\u{1F950} Optimisation Ventes du Vendredi & R\xE9investissement :**

- **Constat** : Vos ventes de pain progressent de +20% le vendredi matin.
- **Action concr\xE8te** : Commandez du beurre en portion ou en plaquette d\xE8s le jeudi apr\xE8s-midi.
- **Argument de vente** : En proposant le beurre ou du lait concentr\xE9 au moment o\xF9 le client demande sa baguette, 4 clients sur 10 prennent l'accompagnement, ce qui fait passer un panier de 150 F CFA \xE0 550 F CFA (+266% de chiffre d'affaires sur ce ticket !).`;
      } else if (q.includes("grossiste") || q.includes("fournisseur") || q.includes("achat") || q.includes("commander")) {
        reply = `**\u{1F4E6} Conseil d'achat et n\xE9gociation grossistes :**

1. **Achetez toujours par carton plein pour les indispensables** (Sucre, Lait, Huile, Savon). L'achat \xE0 l'unit\xE9 chez le demi-grossiste vous fait perdre entre 5% et 12% de marge.
2. **N\xE9gociez un d\xE9lai de paiement de 7 jours** : Si vous r\xE9glez vos grossistes apr\xE8s avoir encaiss\xE9 le cash de vos clients du week-end, vous travaillez avec la tr\xE9sorerie du fournisseur !
3. **Surveillez les dates de p\xE9remption** d\xE8s la r\xE9ception du carton pour ne jamais accepter un lot proche de l'expiration.`;
      } else {
        reply = `**\u2728 Analyse financi\xE8re de votre boutique par Gemini :**

- **Priorit\xE9 1 (Liquidit\xE9s)** : Vous avez plus de 100 000 F CFA de dettes dans votre carnet. R\xE9cup\xE9rer un quart de cette somme (25 000 F CFA) vous donne le cash n\xE9cessaire pour r\xE9approvisionner le Sucre et les conserves sans toucher \xE0 votre r\xE9serve personnelle.
- **Priorit\xE9 2 (Anti-Rupture)** : Le Sucre et les produits \xE0 moins de 5 unit\xE9s (Tomate, Sardines, Spaghetti) doivent \xEAtre command\xE9s d'urgence pour ne pas perdre vos clients au profit de la boutique voisine.
- **Priorit\xE9 3 (Opportunit\xE9)** : D\xE9veloppez les ventes associ\xE9es (Pain + Beurre/Lait) le vendredi matin pour booster la marge moyenne par client.`;
      }
      res.json({
        success: true,
        source: "local-financial-engine",
        reply
      });
    } catch (err) {
      console.error("Chat route error:", err);
      res.status(500).json({ error: err.message || "Internal server error" });
    }
  });
  app.post("/api/ai/marketing", async (req, res) => {
    try {
      const {
        productName = "",
        keyFeatures = "",
        channel = "DESCRIPTION",
        storeName = "Votre Boutique",
        price = 0
      } = req.body;
      if (!productName || productName.trim() === "") {
        return res.status(400).json({ error: "Le nom du produit est requis" });
      }
      const formattedPrice = price > 0 ? `${Number(price).toLocaleString("fr-FR")} F CFA` : "Prix attractif en boutique";
      const ai = getGenAI();
      if (ai) {
        try {
          let channelPromptDescription = "";
          switch (channel) {
            case "TIKTOK_REELS":
              channelPromptDescription = `un Script Vid\xE9o Court (TikTok / Reels / Shorts, 30 \xE0 45 secondes) ultra-captivant :
- [0-3s] ACCROCHE CHOC VISUELLE ET AUDITIVE : Une phrase directe qui arr\xEAte le scroll imm\xE9diatement (probl\xE8me client ou curiosit\xE9).
- [3-15s] LE PROBL\xC8ME / D\xC9SIR : Pourquoi les clients gal\xE8rent sans ce produit.
- [15-30s] LA D\xC9MO / SOLUTION : Mise en valeur des fonctionnalit\xE9s cl\xE9s (${keyFeatures || "qualit\xE9 premium"}).
- [30-45s] APPEL \xC0 L'ACTION (CTA) : Prix (${formattedPrice}), stock limit\xE9, et invitation \xE0 cliquer sur le lien WhatsApp ou profil pour commander.
Formatte le script avec les indications visuelles [Visuel] et paroles [Voix off].`;
              break;
            case "FACEBOOK":
              channelPromptDescription = `une Publication Facebook & Instagram \xE0 fort engagement commercial :
- Titre accrocheur avec emojis percutants.
- Histoire courte ou situation quotidienne reconnaissable pour le client africain.
- Liste des 3 \xE0 4 b\xE9n\xE9fices concrets sous forme de puces claires.
- Offre irr\xE9sistible avec le prix clair : ${formattedPrice}.
- Appel \xE0 l'action pr\xE9cis (Ex: "Cliquez sur notre lien WhatsApp pour r\xE9server ou commentez 'INFOS'").
- 3 \xE0 5 hashtags cibl\xE9s (#AfriqueCommerce, #${productName.replace(/\s+/g, "")}, etc.).`;
              break;
            case "WHATSAPP_CLOSING":
              channelPromptDescription = `un Message de Closing Commercial WhatsApp pr\xEAt \xE0 envoyer \xE0 un client int\xE9ress\xE9 :
- Salutation chaleureuse, personnalis\xE9e et respectueuse.
- Confirmation enthousiaste de la disponibilit\xE9 de ${productName}.
- R\xE9assurance sur la qualit\xE9, l'authenticit\xE9 et la garantie satisfaction.
- Rappel du prix net (${formattedPrice}) et des options de livraison rapide ou retrait boutique chez ${storeName}.
- Question de closing engageante pour conclure la vente imm\xE9diatement (ex: "Pr\xE9f\xE9rez-vous \xEAtre livr\xE9 cet apr\xE8s-midi \xE0 domicile ou au bureau ?").`;
              break;
            case "DESCRIPTION":
            default:
              channelPromptDescription = `une Description de Produit pour Vitrine Web E-commerce :
- Accroche percutante qui donne envie d'acheter d\xE8s les premiers mots.
- Pr\xE9sentation \xE9l\xE9gante et vendeuse du produit (${productName}).
- Points forts et caract\xE9ristiques d\xE9taill\xE9es (${keyFeatures || "Qualit\xE9 sup\xE9rieure garantie"}).
- Pourquoi choisir ${storeName} (authenticit\xE9, rapidit\xE9, service client r\xE9actif).
- Prix affich\xE9 : ${formattedPrice}.
- Appel \xE0 l'action clair et rassurant pour passer commande.`;
              break;
          }
          const systemInstruction = `Tu es l'Expert en Copywriting et Strat\xE9gie Marketing E-commerce de Nana POS.
Tu es sp\xE9cialis\xE9 dans la vente au d\xE9tail et en ligne pour les commer\xE7ants en Afrique francophone (monnaie : Franc CFA / F CFA).
R\xE8gles :
- Ton style est dynamique, vendeur, engageant et professionnel.
- Utilise des emojis adapt\xE9s avec mod\xE9ration pour structurer visuellement le texte.
- Int\xE8gre naturellement les arguments de vente et la monnaie F CFA.
- Ne mentionne pas de balises techniques ou de m\xE9tadonn\xE9es, fournis directement le texte final pr\xEAt \xE0 \xEAtre publi\xE9 ou envoy\xE9 par le commer\xE7ant.`;
          const prompt = `G\xE9n\xE8re ${channelPromptDescription}
Donn\xE9es du produit :
- Nom de l'article : ${productName}
- Caract\xE9ristiques cl\xE9s fournies : ${keyFeatures || "Article de qualit\xE9 sup\xE9rieure, disponible en boutique."}
- Boutique vendeuse : ${storeName}
- Prix : ${formattedPrice}`;
          const geminiResult = await callGeminiWithRetry(ai, {
            contents: prompt,
            config: {
              systemInstruction,
              temperature: 0.7
            }
          });
          if (geminiResult && geminiResult.text) {
            return res.json({
              success: true,
              source: geminiResult.modelUsed,
              channel,
              copyText: geminiResult.text.trim()
            });
          }
        } catch (apiErr) {
          console.warn("Gemini marketing generation fallback:", apiErr);
        }
      }
      let fallbackCopy = "";
      const safeFeatures = keyFeatures ? keyFeatures.trim() : "Qualit\xE9 garantie, satisfaction assur\xE9e";
      switch (channel) {
        case "TIKTOK_REELS":
          fallbackCopy = `\u{1F3AC} [SCRIPT TIKTOK / REELS : ${productName.toUpperCase()}]

[0-3s | Visuel : Plan serr\xE9 sur le produit avec un geste dynamique]
\u{1F5E3}\uFE0F Voix Off : "Attendez ! Si vous cherchez le meilleur pour votre quotidien, regardez ceci..."

[3-15s | Visuel : D\xE9monstration de l'utilisation en situation r\xE9elle]
\u{1F5E3}\uFE0F Voix Off : "Fini les produits de mauvaise qualit\xE9 qui ne durent pas ! D\xE9couvrez ${productName}. C'est exactement ce qu'il vous faut pour faire la diff\xE9rence."

[15-30s | Visuel : Gros plan sur les d\xE9tails et fonctionnalit\xE9s]
\u{1F5E3}\uFE0F Voix Off : "Pourquoi tout le monde en parle ?
\u2728 ${safeFeatures.replace(/\n/g, " ")}
C'est certifi\xE9, test\xE9 et approuv\xE9 par nos clients !"

[30-45s | Visuel : Le commer\xE7ant tenant le produit avec le sourire]
\u{1F5E3}\uFE0F Voix Off : "Disponible d\xE8s maintenant \xE0 seulement ${formattedPrice} chez ${storeName} ! Attention, les stocks partent tr\xE8s vite. Cliquez sur le lien WhatsApp dans notre bio pour commander avant la rupture !" \u{1F525}\u{1F4E6}`;
          break;
        case "FACEBOOK":
          fallbackCopy = `\u{1F525} ARRIVAGE EXCLUSIF CHEZ ${storeName.toUpperCase()} ! \u{1F525}

Vous nous l'avez demand\xE9, il est enfin disponible ! D\xE9couvrez d\xE8s aujourd'hui :
\u{1F449} *${productName}*

\u{1F4A1} Ce qui fait toute la diff\xE9rence :
\u2705 ${safeFeatures.replace(/\n/g, "\n\u2705 ")}
\u2705 Garantie authenticit\xE9 et satisfaction 100%
\u2705 Disponible imm\xE9diatement en magasin ou en livraison express

\u{1F4B0} Tarif promo exceptionnel : *${formattedPrice}*
\u26A0\uFE0F Stock limit\xE9 selon les arrivages de la semaine !

\u{1F4F2} Comment commander ?
1\uFE0F\u20E3 \xC9crivez-nous directement sur WhatsApp en cliquant sur notre lien
2\uFE0F\u20E3 Ou commentez "JE VEUX" sous ce post et nous vous r\xE9pondons dans la minute !

\u{1F69A} Livraison rapide et s\xE9curis\xE9e. Paiement cash \xE0 la livraison ou par Mobile Money.
#${productName.replace(/[^a-zA-Z0-9]/g, "")} #BoutiqueNana #CommerceLocal #PromoDuJour`;
          break;
        case "WHATSAPP_CLOSING":
          fallbackCopy = `Bonjour et merci pour votre message ! \u{1F60A}

C'est un excellent choix. Nous avons bien en stock l'article *${productName}*.

Voici ce que nos clients appr\xE9cient particuli\xE8rement :
\u{1F48E} ${safeFeatures.replace(/\n/g, " - ")}

\u{1F3F7}\uFE0F *Prix : ${formattedPrice}*
\u{1F4E6} Disponibilit\xE9 : En stock imm\xE9diat chez *${storeName}*

Nous pouvons vous l'exp\xE9dier d\xE8s aujourd'hui avec notre livreur ou vous le r\xE9server en boutique.

\u{1F449} *Souhaitez-vous \xEAtre livr\xE9 directement chez vous ou pr\xE9f\xE9rez-vous passer r\xE9cup\xE9rer votre colis ?* (Indiquez-moi simplement votre quartier ou contact) \u{1F44D}`;
          break;
        case "DESCRIPTION":
        default:
          fallbackCopy = `\u2B50 ${productName.toUpperCase()} - L'EXCELLENCE POUR VOTRE QUOTIDIEN

Offrez-vous ce qu'il y a de meilleur avec *${productName}*. Con\xE7u pour r\xE9pondre aux exigences les plus strictes de durabilit\xE9 et d'efficacit\xE9, ce produit est le choix id\xE9al pour un usage quotidien optimal.

\u2728 CARACT\xC9RISTIQUES PRINCIPALES :
\u2022 ${safeFeatures.replace(/\n/g, "\n\u2022 ")}
\u2022 Qualit\xE9 premium rigoureusement s\xE9lectionn\xE9e par ${storeName}
\u2022 Excellent rapport qualit\xE9-prix

\u{1F3F7}\uFE0F PRIX : ${formattedPrice}

\u{1F6E1}\uFE0F ENGAGEMENT QUALIT\xC9 :
Produit 100% authentique. Commandez d\xE8s maintenant en toute confiance avec livraison rapide et service client d\xE9di\xE9.`;
          break;
      }
      res.json({
        success: true,
        source: "nana-heuristic-engine",
        channel,
        copyText: fallbackCopy
      });
    } catch (err) {
      console.error("Marketing route error:", err);
      res.status(500).json({ error: err.message || "Internal server error" });
    }
  });
  app.post("/api/ai/resume-enhance", async (req, res) => {
    try {
      const { title = "", bulletText = "" } = req.body;
      if (!bulletText || !bulletText.trim()) {
        return res.status(400).json({ error: "Texte \xE0 am\xE9liorer manquant" });
      }
      const prompt = `En tant qu'expert international en recrutement RH, optimise les r\xE9alisations professionnelles suivantes pour un CV moderne au poste de "${title || "Professionnel"}".
R\xE8gles strictes :
- Reformule chaque point pour le rendre percutant, orient\xE9 r\xE9sultat avec verbe d'action fort.
- Conserve le sens d'origine sans inventer de faux faits, mais valorise l'impact et la rigueur.
- Renvoie UNIQUEMENT la liste des puces (chaque puce commen\xE7ant par "\u2022 ") sans texte avant ni apr\xE8s.

Texte d'origine :
${bulletText}`;
      const ai = getGenAI();
      if (ai) {
        const result = await callGeminiWithRetry(ai, {
          contents: [{ role: "user", parts: [{ text: prompt }] }]
        });
        if (result && result.text) {
          return res.json({
            success: true,
            enhancedText: result.text.trim(),
            source: result.modelUsed
          });
        }
      }
      const lines = bulletText.split("\n").map((l) => l.replace(/^[•\-\*]\s*/, "").trim()).filter(Boolean);
      const enhancedFallback = lines.map((line) => {
        const capitalized = line.charAt(0).toUpperCase() + line.slice(1);
        return `\u2022 Pilotage et r\xE9alisation avec succ\xE8s : ${capitalized}, en garantissant qualit\xE9, conformit\xE9 et respect des d\xE9lais op\xE9rationnels.`;
      }).join("\n");
      res.json({
        success: true,
        enhancedText: enhancedFallback || `\u2022 ${bulletText}`,
        source: "nana-heuristic-engine"
      });
    } catch (err) {
      console.error("Resume enhance route error:", err);
      res.status(500).json({ error: err.message || "Internal server error" });
    }
  });
  app.post("/api/ai/cover-letter", async (req, res) => {
    try {
      const { candidateName = "", title = "", skills = [], targetCompany = "" } = req.body;
      const skillsStr = Array.isArray(skills) ? skills.slice(0, 6).join(", ") : "";
      const prompt = `R\xE9dige un message court, percutant et professionnel (120 \xE0 180 mots) pour une candidature directe sur LinkedIn ou par email pour le poste de "${title || "Poste vis\xE9"}"${targetCompany ? ` aupr\xE8s de l'entreprise ${targetCompany}` : ""}.
Le candidat s'appelle ${candidateName || "le candidat"}.
Comp\xE9tences cl\xE9s : ${skillsStr || "Gestion, Organisation, Relation client, Esprit d'\xE9quipe"}.
Style : Dynamique, courtois, ax\xE9 sur la valeur ajout\xE9e imm\xE9diate et le professionnalisme.
Renvoie uniquement le texte du message pr\xEAt \xE0 \xEAtre envoy\xE9.`;
      const ai = getGenAI();
      if (ai) {
        const result = await callGeminiWithRetry(ai, {
          contents: [{ role: "user", parts: [{ text: prompt }] }]
        });
        if (result && result.text) {
          return res.json({
            success: true,
            letter: result.text.trim(),
            source: result.modelUsed
          });
        }
      }
      const fallbackMsg = `Madame, Monsieur,

Je me permets de vous contacter afin de vous pr\xE9senter ma candidature au poste de ${title || "ce r\xF4le"} au sein de votre structure${targetCompany ? ` chez ${targetCompany}` : ""}.

Fort d'un parcours solide et ax\xE9 sur l'efficacit\xE9 op\xE9rationnelle, je mets \xE0 votre disposition mes comp\xE9tences cl\xE9s en ${skillsStr || "gestion, rigueur et coordination d\u2019activit\xE9s"}. Reconnue pour mon sens de l'organisation et mon adaptabilit\xE9, je suis enthousiaste \xE0 l'id\xE9e d'apporter une contribution concr\xE8te \xE0 vos projets et \xE0 la performance de vos \xE9quipes.

Je me tiens \xE0 votre enti\xE8re disposition pour \xE9changer de vive voix lors d'un entretien.

Bien cordialement,
${candidateName || "Le Candidat"}`;
      res.json({
        success: true,
        letter: fallbackMsg,
        source: "nana-heuristic-engine"
      });
    } catch (err) {
      console.error("Cover letter route error:", err);
      res.status(500).json({ error: err.message || "Internal server error" });
    }
  });
  if (process.env.NODE_ENV !== "production") {
    const vite = await (0, import_vite.createServer)({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = import_path.default.join(process.cwd(), "dist");
    app.use(import_express.default.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(import_path.default.join(distPath, "index.html"));
    });
  }
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Nana Server with Gemini AI running on http://0.0.0.0:${PORT}`);
  });
}
startServer();
//# sourceMappingURL=server.cjs.map
