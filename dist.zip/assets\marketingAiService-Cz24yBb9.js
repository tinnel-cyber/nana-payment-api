import{ak as m,n as h,o as v,q as I,s as y}from"./index-CisXcFr6.js";const d=5;function p(e){if(!e)try{const t=localStorage.getItem("nana_store_sub");t&&(e=JSON.parse(t))}catch{}if(!e)return!1;const c=(e.status||"").toLowerCase(),n=(e.plan||"").toLowerCase(),a=c==="active"||n==="pro"||n.includes("pro")||n==="monthly_1"||n==="quarterly_3"||n==="semester_6"||n==="annual_12",o=!e.expiresAt||e.expiresAt>Date.now();return!!(a&&o)}async function C(e,c){var i,l;if(p(c))return{used:0,limit:1/0,remaining:1/0,isUnlimited:!0};const a=e||((i=m.currentUser)==null?void 0:i.uid)||"guest-merchant",o=`nana_ai_marketing_quota_${a}`;let t=0;try{const s=localStorage.getItem(o);s&&(t=parseInt(s,10)||0)}catch{}if((l=m.currentUser)!=null&&l.uid&&a===m.currentUser.uid)try{const s=h(v,"merchants",a,"ai_marketing","quota"),u=await I(s);if(u.exists()){const f=u.data();typeof f.usedCount=="number"&&(t=Math.max(t,f.usedCount),localStorage.setItem(o,String(t)))}}catch{}const r=Math.max(0,d-t);return{used:t,limit:d,remaining:r,isUnlimited:!1}}async function g(e,c){var i,l;if(p(c))return{used:0,limit:1/0,remaining:1/0,isUnlimited:!0};const a=e||((i=m.currentUser)==null?void 0:i.uid)||"guest-merchant",o=`nana_ai_marketing_quota_${a}`;let t=0;try{const s=localStorage.getItem(o);s&&(t=parseInt(s,10)||0)}catch{}const r=t+1;try{localStorage.setItem(o,String(r))}catch{}if((l=m.currentUser)!=null&&l.uid&&a===m.currentUser.uid)try{const s=h(v,"merchants",a,"ai_marketing","quota");await y(s,{usedCount:r,lastGeneratedAt:Date.now(),limit:d},{merge:!0})}catch{}return{used:r,limit:d,remaining:Math.max(0,d-r),isUnlimited:!1}}async function E(e,c){const n=p(c);if(!n&&(await C(e.userId,c)).remaining<=0)throw new Error("Vous avez épuisé vos 5 générations gratuites. Passez au forfait Pro pour débloquer l'accès illimité !");try{const i=new AbortController,l=setTimeout(()=>i.abort(),12e3),s=await fetch("/api/ai/marketing",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({productName:e.productName,keyFeatures:e.keyFeatures||"",channel:e.channel,storeName:e.storeName||"Votre Boutique",price:e.price||0}),signal:i.signal});if(clearTimeout(l),s.ok){const u=await s.json();if(u&&typeof u.copyText=="string"&&u.copyText.trim())return n||await g(e.userId,c),{text:u.copyText.trim(),source:u.source||"gemini-3.8-flash",success:!0}}}catch(i){console.warn("Échec de l'appel serveur /api/ai/marketing, bascule sur le moteur local :",i==null?void 0:i.message)}const a=e.price&&e.price>0?`${Number(e.price).toLocaleString("fr-FR")} F CFA`:"Prix attractif en boutique",o=e.keyFeatures?e.keyFeatures.trim():"Qualité supérieure garantie, satisfaction assurée",t=e.storeName||"Notre Boutique";let r="";switch(e.channel){case"TIKTOK_REELS":r=`🎬 [SCRIPT TIKTOK / REELS : ${e.productName.toUpperCase()}]

[0-3s | Visuel : Plan serré sur le produit avec un geste dynamique]
🗣️ Voix Off : "Attendez ! Si vous cherchez le meilleur pour votre quotidien, regardez ceci..."

[3-15s | Visuel : Démonstration de l'utilisation en situation réelle]
🗣️ Voix Off : "Fini les produits décevants ! Découvrez ${e.productName}. C'est exactement ce qu'il vous faut."

[15-30s | Visuel : Gros plan sur les détails et fonctionnalités]
🗣️ Voix Off : "Pourquoi tout le monde en parle ?
✨ ${o.replace(/\n/g," ")}
C'est testé et approuvé par nos clients !"

[30-45s | Visuel : Le commerçant tenant le produit avec le sourire]
🗣️ Voix Off : "Disponible dès maintenant à seulement ${a} chez ${t} ! Cliquez sur le lien WhatsApp dans notre bio pour commander avant la rupture !" 🔥📦`;break;case"FACEBOOK":r=`🔥 ARRIVAGE EXCLUSIF CHEZ ${t.toUpperCase()} ! 🔥

Vous nous l'avez demandé, il est enfin disponible ! Découvrez dès aujourd'hui :
👉 *${e.productName}*

💡 Ce qui fait toute la différence :
✅ ${o.replace(/\n/g,`
✅ `)}
✅ Garantie authenticité et satisfaction 100%
✅ Disponible immédiatement en magasin ou en livraison express

💰 Tarif promo exceptionnel : *${a}*
⚠️ Stock limité selon les arrivages de la semaine !

📲 Comment commander ?
1️⃣ Écrivez-nous directement sur WhatsApp en cliquant sur notre lien
2️⃣ Ou commentez "JE VEUX" sous ce post et nous vous répondons dans la minute !

🚚 Livraison rapide et sécurisée. Paiement cash à la livraison ou par Mobile Money.
#${e.productName.replace(/[^a-zA-Z0-9]/g,"")} #BoutiqueNana #CommerceLocal #PromoDuJour`;break;case"WHATSAPP_CLOSING":r=`Bonjour et merci pour votre message ! 😊

C'est un excellent choix. Nous avons bien en stock l'article *${e.productName}*.

Voici ce que nos clients apprécient particulièrement :
💎 ${o.replace(/\n/g," - ")}

🏷️ *Prix : ${a}*
📦 Disponibilité : En stock immédiat chez *${t}*

Nous pouvons vous l'expédier dès aujourd'hui avec notre livreur ou vous le réserver en boutique.

👉 *Souhaitez-vous être livré directement chez vous ou préférez-vous passer récupérer votre colis ?* (Indiquez-moi simplement votre quartier ou contact) 👍`;break;case"DESCRIPTION":default:r=`⭐ ${e.productName.toUpperCase()} - L'EXCELLENCE POUR VOTRE QUOTIDIEN

Offrez-vous ce qu'il y a de meilleur avec *${e.productName}*. Conçu pour répondre aux exigences les plus strictes de durabilité et d'efficacité, ce produit est le choix idéal pour un usage quotidien optimal.

✨ CARACTÉRISTIQUES PRINCIPALES :
• ${o.replace(/\n/g,`
• `)}
• Qualité premium rigoureusement sélectionnée par ${t}
• Excellent rapport qualité-prix

🏷️ PRIX : ${a}

🛡️ ENGAGEMENT QUALITÉ :
Produit 100% authentique. Commandez dès maintenant en toute confiance avec livraison rapide et service client dédié.`;break}return n||await g(e.userId,c),{text:r,source:"nana-heuristic-engine",success:!0}}export{d as F,E as a,p as c,C as g};
